import EditProfile from "@/components/doctorProfile/EditProfile";

function EditProfilePage() {
  return <EditProfile />;
}

export default EditProfilePage;
