import React from "react";
import Appointments from "@/components/doctorProfile/Appointments";
const AppointmentsPage = () => {
  return <Appointments />;
};

export default AppointmentsPage;
