"use client";
import DoctorBooking from "@/components/booking/DoctorBooking";

export default function BookingPage() {
  return <DoctorBooking />;
}
