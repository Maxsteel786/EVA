import React from "react";
import Appointments from "@/components/patientProfile/appointments_history/Appointments";
const AppointmentsPage = () => {
  return <Appointments />;
};

export default AppointmentsPage;
