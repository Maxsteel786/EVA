import ViewPaymentInfo from "@/components/patientProfile/ViewPaymentInfo";

function ViewPaymentInfoPage() {
  return <ViewPaymentInfo />;
}

export default ViewPaymentInfoPage;
